INSERT INTO laboratorista
(ci,sexo,nombre,apellido_paterno,apellido_materno,telefono,direccion)
VALUES 
(4853205  ,'1' ,'Pablo'  ,'Cuellar'  ,'Escalera'  ,79956121  ,'Barrio Petrolero'),
(5145888  ,'1' ,'Pablo'  ,'Mamani'   ,'Escalera'  ,79956122  ,'Barrio Petrolero'),
(5145887  ,'1' ,'Manuel' ,'Quispe'   ,'Escalera'  ,79956123  ,'Barrio Petrolero'),
(5145889  ,'1' ,'Manuel' ,'Zambrana' ,'Tola'      ,79956134  ,'Barrio Petrolero'),
(5145882  ,'1' ,'Gorge'  ,'Flores'   ,'Tola'      ,79956135  ,'Villa Urkupinia'),
(5145881  ,'0' ,'Maria'  ,'Rosas'    ,'Tola'      ,79956136  ,'Villa Urkupinia'),
(5145875  ,'0' ,'Maria'  ,'Lujan'    ,'Wilson'    ,79956147  ,'Villa Urkupinia'),
(5145880  ,'0' ,'Ster'   ,'Rocha'    ,'Wilson'    ,79956148  ,'Villa Urkupinia'),
(5145878  ,'0' ,'Ster'   ,'Siles'    ,'Wilson'    ,79956149  ,'Barrio Solterito'),
(5145896  ,'0' ,'Eva'    ,'Luna'     ,'Flores'    ,79956160  ,'Barrio Solterito'), 
(5145836  ,'0' ,'Eva'    ,'Aguilar'  ,'Flores'    ,79956860  ,'Barrio Solterito');
